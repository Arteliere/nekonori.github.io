const fs = require('fs');
const path = require('path');
function read(p){ try { return fs.readFileSync(p,'utf8'); } catch(e){ return null; } }
const base = path.resolve(__dirname,'..');
const index = read(path.join(base,'index.html'));
const js = read(path.join(base,'assets','js','three-up-slider.js'));
const css = read(path.join(base,'assets','css','three-up-slider.css'));
const out = [];
let ok = true;
if(!index){ out.push('FAIL: index.html not found'); ok=false; }
else { out.push('OK: index.html found');
  out.push(/three-up-slider/.test(index)?'OK: three-up-slider section present':'FAIL: three-up-slider not found');
  out.push(/assets\/css\/three-up-slider\.css/.test(index)?'OK: CSS link present':'FAIL: CSS link missing');
  out.push(/assets\/js\/three-up-slider\.js/.test(index)?'OK: JS include present':'FAIL: JS include missing');
}
if(!js){ out.push('FAIL: three-up-slider.js missing'); ok=false; } else { out.push('OK: three-up-slider.js found'); out.push(/class\s+ThreeUpSlider/.test(js)?'OK: ThreeUpSlider class present':'WARN: class not found'); }
if(!css){ out.push('FAIL: three-up-slider.css missing'); ok=false; } else { out.push('OK: three-up-slider.css found'); out.push(/\.three-up-slider/.test(css)?'OK: .three-up-slider rules present':'WARN: .three-up-slider rules not found in css'); }
console.log(out.join('\n'));
process.exit(ok?0:2);
